{
  "resourceType": "GMScript",
  "resourceVersion": "1.0",
  "name": "TGMX_6_TweenTools",
  "isDnD": false,
  "isCompatibility": false,
  "parent": {
    "name": "User",
    "path": "folders/TweenGMX/User.yy",
  },
}