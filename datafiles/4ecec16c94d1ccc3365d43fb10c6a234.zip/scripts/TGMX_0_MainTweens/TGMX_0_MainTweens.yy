{
  "resourceType": "GMScript",
  "resourceVersion": "1.0",
  "name": "TGMX_0_MainTweens",
  "isDnD": false,
  "isCompatibility": false,
  "parent": {
    "name": "User",
    "path": "folders/TweenGMX/User.yy",
  },
}